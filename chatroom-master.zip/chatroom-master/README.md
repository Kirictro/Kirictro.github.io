# chatroom
简易聊天室,
使用nodejs开发,
将app.js中的http.listen()中的端口和ip修改为自己对应的端口和ip即可
